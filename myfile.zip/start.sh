#!/bin/bash
service nginx start
exec $@
